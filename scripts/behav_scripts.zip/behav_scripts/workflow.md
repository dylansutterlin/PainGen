## General workflow for pain generalization project

Run analyze_main_SCEBL_fMRI_only36FinalSubjects.m 
	output : save in /results/SCEBLmri_data_FINAL_N36.mat

Run extractSCEBmri_dataFrame.m 
	saves Trial x Trial in a .csv at /results/SCEBLmri_Finaldata_TxT_N36.csv 
run analyze_simrate.m (~/LKscripts)
	outputs/~results/simmat.mat  simrate.mat 
	 # modified simrate, to export simmat3 (order of cond diff)

run SCEBmri_gen_isolate.m (adaptaed from LKscript/analyze_gen_SCEBL_fMRI.m)
	output ~/results/SCEBLmri_data_gen36.mat (SCEBLmri_gendata variable)

## compilation script (not up to date ?, run all above and skip this)
preproc_MainSimateGen_SCEBLmri.m

contains main simrate and gen script from LKscripts/* mentioned above

## export main var to dataframes and compute similarity matrices (theoric and empirical)
run extract_LearnGenData_csv.m
	- also process trial by trial sim ratings, as well as
	-  median sim matrices
	- Save SCEBLmri_gendata.mat (with added var) to ~/results
 
## Extract outputs from ~/results to perform main contrasts
Script name : ~/scripts/LKscriptOutput_mainEffects.m

This script saves 






# Useful code

### np.unique(x, return_counts=True)
[uniqueValues, ~, idx] = unique(x);
counts = histcounts(idx, 1:numel(uniqueValues)+1);

% Display unique values and counts
disp('Unique Values:');
disp(uniqueValues');
disp('Counts:');
disp(counts');

